#
# TABLE STRUCTURE FOR: flag
#

DROP TABLE IF EXISTS `flag`;

CREATE TABLE `flag` (
  `id_flag` int(10) NOT NULL AUTO_INCREMENT,
  `nama_flag` varchar(50) NOT NULL,
  PRIMARY KEY (`id_flag`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `flag` (`id_flag`, `nama_flag`) VALUES (1, 'Pending');
INSERT INTO `flag` (`id_flag`, `nama_flag`) VALUES (2, 'Ditindaklanjuti');
INSERT INTO `flag` (`id_flag`, `nama_flag`) VALUES (3, 'Selesai');
INSERT INTO `flag` (`id_flag`, `nama_flag`) VALUES (4, 'Selesai dan Telah Dimonitoring');


#
# TABLE STRUCTURE FOR: kategori
#

DROP TABLE IF EXISTS `kategori`;

CREATE TABLE `kategori` (
  `id_kat` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(255) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `for_modul` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_kat`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (2, 'Kategori b', '-', '-');
INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (4, 'Desa', '-', 'jenis_lokasi');
INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (5, 'Radio', '-', 'jenis_perangkat');
INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (6, 'Kecamatan', '', 'jenis_lokasi');
INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (7, 'OPD', '', 'jenis_lokasi');
INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (8, 'PDE', '', 'jenis_perangkat');
INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (9, 'Access Point', '', 'jenis_perangkat');
INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (10, 'Router', '', 'jenis_perangkat');
INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (11, 'Repeater Bojong', '', 'jenis_perangkat');


#
# TABLE STRUCTURE FOR: master_access
#

DROP TABLE IF EXISTS `master_access`;

CREATE TABLE `master_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nm_access` varchar(255) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `id_menu` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (21, 'Laporan', 'Akses ke menu Laporan', '2022-05-23 08:38:43', 8, 33);
INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (22, 'Pengaturan Aplikasi', 'Akses ke menu Parameter System', '2022-05-23 08:39:26', 8, 13);
INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (23, 'Management User', 'Akses ke menu Management User', '2022-05-23 08:39:53', 8, 18);
INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (24, 'Menu Config', 'Akses ke menu Config', '2022-05-23 08:40:20', 8, 5);
INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (30, 'User', 'Akses ke menu User', '2022-05-23 09:50:22', 6, 14);
INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (31, 'Group User', 'Akses ke menu Group User', '2022-05-23 09:50:52', 6, 15);
INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (32, 'Master Akses', 'Akses ke menu master Akses', '2022-05-23 09:51:10', 6, 17);
INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (33, 'User Akses', 'akses ke menu User Akses', '2022-05-23 09:51:36', 6, 16);
INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (39, 'Data Aduan', 'Data Aduan', '2022-08-01 11:19:17', 6, 37);
INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (40, 'ADUAN_ACTION', '1', '2022-08-01 12:26:52', 6, 37);
INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (41, 'Dashboard', '1', '2022-08-01 18:18:33', 6, 6);
INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (42, 'CREATE_BUTTON', 'Tombol Create pada menu Data Aduan', '2022-08-01 18:22:35', 6, 37);
INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (43, 'CREATE_TINDAKLANJUT', 'Tombol TIndak lanjut pada menu Aduan', '2022-08-01 18:27:03', 6, 37);
INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (44, 'CETAK_LIST_PRINT', 'Akses tombol cetak list Print', '2022-08-07 09:17:37', 6, 6);
INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (45, 'CETAK_REKAP_PRINT', 'Akses tombol cetak rekap print', '2022-08-07 09:18:02', 6, 33);


#
# TABLE STRUCTURE FOR: sy_config
#

DROP TABLE IF EXISTS `sy_config`;

CREATE TABLE `sy_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conf_name` varchar(50) NOT NULL,
  `conf_val` text NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

INSERT INTO `sy_config` (`id`, `conf_name`, `conf_val`, `note`) VALUES (3, 'APP_NAME', 'e-PAS', '');
INSERT INTO `sy_config` (`id`, `conf_name`, `conf_val`, `note`) VALUES (8, 'OPD_NAME', 'Dinkominfo', '');
INSERT INTO `sy_config` (`id`, `conf_name`, `conf_val`, `note`) VALUES (9, 'LEFT_FOOTER', '<strong>Copyright</strong> <a href=\"\">Kominfo Temanggung</a> © 2022', '');
INSERT INTO `sy_config` (`id`, `conf_name`, `conf_val`, `note`) VALUES (10, 'RIGHT_FOOTER', 'DInKominfo Temanggung', '');
INSERT INTO `sy_config` (`id`, `conf_name`, `conf_val`, `note`) VALUES (11, 'VISI_MISI', 'VISI: “TERWUJUDNYA MASYARAKAT TEMANGGUNG YANG TENTREM, MAREM, GANDEM”\r\n\r\nMisi Pembangunan Daerah :\r\n1. Mewujudkan sumber daya manusia yang berkualitas, berkarakter, dan berdaya;\r\n2. Mewujudkan pemberdayaan ekonomi kerakyatan yang berbasis potensi unggulan daerah dan berkelanjutan;\r\n3. Mewujudkan tata kelola pemerintahan yang baik dan pelayanan publik yang berkualitas;', '');
INSERT INTO `sy_config` (`id`, `conf_name`, `conf_val`, `note`) VALUES (12, 'OPD_ADDR', '<a href=\"\">Jl. Jenderal Sudirman No.41-42, Dongkelan Selatan, Kertosari, Temanggung, Temanggung Regency, Central Java 56216</a>', '');


#
# TABLE STRUCTURE FOR: sy_menu
#

DROP TABLE IF EXISTS `sy_menu`;

CREATE TABLE `sy_menu` (
  `id_menu` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(30) DEFAULT '',
  `redirect` int(1) DEFAULT NULL,
  `url` varchar(100) DEFAULT '',
  `parent` int(11) DEFAULT 0,
  `icon` varchar(30) DEFAULT NULL,
  `note` varchar(100) DEFAULT NULL,
  `order_no` int(5) DEFAULT NULL,
  `created_by` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` varchar(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_menu`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (5, 'Menu Config', 0, 'sy_menu', 0, 'fa-wrench', '', 10, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');
INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (6, 'Dashboard', 0, 'backend', 0, 'fa-home', '', 0, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');
INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (13, 'Parameter System', 0, 'sy_config', 0, 'fa-gears', '', 9, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');
INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (14, 'Users', 0, 'users', 18, 'fa-users', '', 9, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');
INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (15, 'Group Users', 0, 'user_group', 18, 'fa-users', '', 9, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');
INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (16, 'User Access', 0, 'user_access', 18, 'fa fa-user', '', 8, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');
INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (17, 'Master Access', 0, 'master_access', 18, 'fa fa-key', '', 9, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');
INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (18, 'Management Users', 0, 'users', 0, 'fa fa-users', '', 9, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');
INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (33, 'Laporan', 0, 'Laporan', 0, 'fa-print', 'Menu Laporan', 3, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');
INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (37, 'Data Aduan', 0, 'Tiket', 0, 'fa-list', '', 2, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: tiket
#

DROP TABLE IF EXISTS `tiket`;

CREATE TABLE `tiket` (
  `id_tiket` int(10) NOT NULL AUTO_INCREMENT,
  `no_tiket` varchar(50) NOT NULL,
  `nip` varchar(25) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `no_wa` varchar(25) NOT NULL,
  `nama_opd` varchar(255) NOT NULL,
  `nama_aplikasi` varchar(255) NOT NULL,
  `link_aplikasi` varchar(255) NOT NULL,
  `deskripsi_kendala` longtext NOT NULL,
  `bukti_kendala` longtext DEFAULT NULL,
  `deskripsi_tindaklanjut` longtext DEFAULT NULL,
  `deskripsi_penyelesaian` longtext DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  `create_at` datetime DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `update_at2` datetime DEFAULT NULL,
  `update_by2` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_tiket`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (2, 'PNG2208010001', '424324', '43242343', '432432', '432432', '4324324', '432432', '43243', 'PNG2208010001_1659330219', '', '', 'Pending', '2022-08-01 12:03:39', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '');
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (3, 'PNG2208010002', '3213123', 'qweqweqwe', '3123213', '3213213123', 'qeqeqwewq', 'ewqewqe', 'eqwewqe', 'PNG2208010002_1659330353.jpg', '', '', 'Pending', '2022-08-01 12:05:53', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '');
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (4, 'PNG2208010003', '199105032022021001', 'Akhmad Masruri', '085643538783', 'Dinas Kesehatan Temanggung', 'Pesn Perak', 'pesanperak.temanggungkab.goid', 'tidak bisa dibuka akses', 'PNG2208010003_1659333297.jpg', 'akan dicek terlebih dahulu', '', 'Ditindaklanjuti', '2022-08-01 12:54:57', '2022-08-14 08:41:46', 'Akhmad Masruri', '0000-00-00 00:00:00', '');
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (5, 'PNG2208010004', '3131312121313', 'dadadadsa', '085643538783', 'adsadasdsad', 'dadasdsad', 'dsadsadasd', 'dsadasdsadasd', 'PNG2208010004_1659334006.jpg', '', '', 'Pending', '2022-08-01 13:06:46', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '');
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (6, 'PNG2208010005', '312313123', 'sadadsadsa', '085643538783', 'cxzcxzcz', 'czcxzcxz', 'cxzcxzc', 'czxcxzc', 'PNG2208010005_1659334059.jpg', '', '', 'Pending', '2022-09-01 13:07:39', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '');
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (7, 'PNG2208010006', '12345678', '    Akhmad Masruri', '085643538783', 'wrewrewrewrew', 'werwrwrw', 'rwerewrew', 'erwerewrew', 'PNG2208010006_1660544062.jpg', '', '', 'Pending', '2022-09-01 13:08:36', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '');
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (8, 'PNG2208010007', '454', '444', '4444', '44444', '4444', '4444', '4444', 'PNG2208010007_1659335326.jpg', '', '', 'Pending', '2022-09-01 13:28:46', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '');
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (9, 'PNG2208010008', '32132131', 'ewrrewr', '12321321', '3112123213', '312312321', '321312', '321321321', 'PNG2208010008_1659335711.jpg', '', '', 'Pending', '2022-09-01 13:35:11', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '');
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (10, 'PNG2208130001', '199105032022021001', 'Akhmad Masruri', '085643538783', 'Dinas Komunikasi dan Informatika Kabupaten Temanggung', 'Epasss', 'kominfo.temanggungkab.go.id', 'tidak bisa akses', 'PNG2208130001_1660365307.jpg', 'dasdsaddsadad', 'dilakukan penyelesian dengan mengganti coding aplikasi', 'Selesai', '2022-08-13 11:35:07', '2022-08-14 08:49:46', 'Akhmad Masruri', '2022-08-14 08:57:08', 'Akhmad Masruri');
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (11, 'PNG2208130002', '13213213', 'fsfdsfds', '085643538783', 'sfdsfdsfdsf', 'ssdfsdfdsf', 'fsdfdsfdsf', 'sdfdsfdsf', 'PNG2208130002_1660366306.jpg', 'gdfgdgfdgdgfdg', '', 'Ditindaklanjuti', '2022-08-13 11:51:46', '2022-08-13 13:28:58', 'dev', '0000-00-00 00:00:00', '');
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (12, 'PNG2208140001', '199105032022021001', 'Akhmad Masruri', '085643538783', 'Dinas Komunikasi dan Informatika Temanggung', 'Simpas', 'http://kominfo.temanggungkab.go.id', 'Aplikasi tidak bisa dibuka tampilan time out', 'PNG2208140001_1660444016.jpg', NULL, NULL, 'Pending', '2022-08-14 09:26:56', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (13, 'PNG2208140002', '199105032022021001', 'Akhmad Masruri', '085643538783', 'Dinas Kesehatan Temanggung', 'Simpeda', 'http://localhost/perpus', 'Tidak bisa buka', 'PNG2208140002_1660445163.jpg', NULL, NULL, 'Pending', '2022-08-14 09:46:03', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (14, 'PNG2208140003', '199105032022021001', '434343', '085643538783', 'Dinas Kesehatan Temanggung', 'rewrwrewrw', 'rewrwere', 'sadsads', 'PNG2208140003_1660445638.jpg', NULL, NULL, 'Pending', '2022-08-14 09:53:58', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (15, 'PNG2208140004', '199105032022021001', 'Akhmad Masruri, S.Kom.', '085643538783', 'Dinas Kesehatan Temanggung', 'Coba Aplikasi Epas', 'http://localhost/perpus', 'saldkskd;skd;asd;ad;adsa', 'PNG2208140004_1660449572.jpg', NULL, NULL, 'Pending', '2022-08-14 10:59:32', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (16, 'PNG2208150001', '199105032022021001', 'Akhmad Masruri, S.Kom.', '085643538783', 'Dinas Kesehatan Temanggung', 'Epas', 'http://localhost/perpus', 'Tidak dibuka', 'PNG2208150001_1660528276.jpg', '', '', 'Pending', '2022-08-15 08:51:16', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '');
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (17, 'TA2208150002', '199105032022021001', 'Akhmad Masruri, S.Kom.', '085643538783', 'Dinas Kesehatan Temanggung', 'E retribusi Pasar', 'kominfo.temanggungkab.go.id', 'tidak bisa dibuka', 'TA2208150002_1660533828.jpg', 'dsfdfsfsfsd', NULL, 'Ditindaklanjuti', '2022-08-15 10:23:48', '2022-08-15 11:58:12', 'dev', NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (18, 'TA2208150003', '199105032022021001', '       Akhmad Masruri, S.Kom.', '085643538783', 'Dinas Kesehatan Temanggung', 'Simpoz', 'http://localhost/perpus', 'Tidak bisasasas aksesss', 'TA2208150003_1660562524.jpg', 'ddfgdgdg', NULL, 'Ditindaklanjuti', '2022-08-15 18:22:04', '2022-08-16 06:42:43', 'Akhmad Masruri', NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (19, 'TA2208180001', '199105032022021001', 'Akhmad Masruri', '085643538783', 'Dinas Kesehatan Temanggung', '4324324', 'kominfo.temanggungkab.go.id', 'daadadsadsa', 'TA2208180001_1660783130.jpg', NULL, NULL, 'Pending', '2022-08-18 07:38:50', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (20, 'TA2208180002', '199105032022021001', 'Akhmad Masruri', '085643538783', 'Dinas Kesehatan Temanggung', '4324324', 'kominfo.temanggungkab.go.id', 'daadadsadsa', 'TA2208180002_1660783180.jpg', NULL, NULL, 'Pending', '2022-08-18 07:39:40', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (21, 'TA2208180003', '199105032022021001', 'Akhmad Masruri', '085643538783', 'Dinas Kesehatan Temanggung', '4324324', 'kominfo.temanggungkab.go.id', 'daadadsadsa', 'TA2208180003_1660783379.jpg', NULL, NULL, 'Pending', '2022-08-18 07:42:59', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (22, 'TA2208180004', '199105032022021001', 'Akhmad Masruri, S.Kom.', '085643538783', 'Dinas Kesehatan Temanggung', 'rewrwrewrw', 'kominfo.temanggungkab.go.id', 'rewrewrwrewr', 'TA2208180004_1660783732.jpg', NULL, NULL, 'Pending', '2022-08-18 07:48:52', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (23, 'TA2208180005', '199105032022021001', 'Akhmad Masruri, S.Kom.', '085643538783', 'Dinas Kesehatan Temanggung', 'rewrwrewrw', 'kominfo.temanggungkab.go.id', 'rewrewrwrewr', 'TA2208180005_1660783788.jpg', NULL, NULL, 'Pending', '2022-08-18 07:49:48', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (24, 'TA2208180006', '199105032022021001', 'Akhmad Masruri, S.Kom.', '085643538783', 'Dinas Kesehatan Temanggung', 'rewrwrewrw', 'kominfo.temanggungkab.go.id', 'rewrewrwrewr', 'TA2208180006_1660783820.jpg', NULL, NULL, 'Pending', '2022-08-18 07:50:20', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (25, 'TA2208180007', '199105032022021001', 'Akhmad Masruri, S.Kom.', '085643538783', 'Dinas Kesehatan Temanggung', 'rewrwrewrw', 'kominfo.temanggungkab.go.id', 'rewrewrwrewr', 'TA2208180007_1660783844.jpg', NULL, NULL, 'Pending', '2022-08-18 07:50:44', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (26, 'ADU2208180008', '199105032022021001', 'Akhmad Masruri, S.Kom.', '085643538783', 'Dinas Kesehatan Temanggung', 'rewrwrewrw', 'kominfo.temanggungkab.go.id', 'rewrewrwrewr', 'ADU2208180008_1660784037.jpg', NULL, NULL, 'Pending', '2022-08-18 07:53:57', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (27, 'ADU2208180009', '199105032022021001', 'Akhmad Masruri, S.Kom.', '085643538783', 'Dinas Kesehatan Temanggung', 'rewrwrewrw', 'kominfo.temanggungkab.go.id', 'rewrewrwrewr', 'ADU2208180009_1660784266.jpg', NULL, NULL, 'Pending', '2022-08-18 07:57:46', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (28, 'ADU2208180010', '199105032022021001', 'Akhmad Masruri, S.Kom.', '085643538783', 'Dinas Kesehatan Temanggung', 'rewrwrewrw', 'kominfo.temanggungkab.go.id', 'rewrewrwrewr', 'ADU2208180010_1660784272.jpg', NULL, NULL, 'Pending', '2022-08-18 07:57:52', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (29, 'ADU220818011', '199105032022021001', 'Akhmad Masruri, S.Kom.', '085643538783', 'Dinas Kesehatan Temanggung', 'rewrwrewrw', 'kominfo.temanggungkab.go.id', 'rewrewrwrewr', 'ADU220818011_1660784338.jpg', NULL, NULL, 'Pending', '2022-08-18 07:58:59', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (30, 'ADU220818012', '199105032022021001', 'Akhmad Masruri, S.Kom.', '085643538783', 'Dinas Kesehatan Temanggung', 'rewrwrewrw', 'kominfo.temanggungkab.go.id', 'dfsdfdsf', 'ADU220818012_1660785146.jpg', NULL, NULL, 'Pending', '2022-08-18 08:12:26', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (31, 'ADU220818013', '199105032022021001', 'Akhmad Masruri, S.Kom.', '085643538783', 'Dinas Kesehatan Temanggung', 'rewrwrewrw', 'kominfo.temanggungkab.go.id', 'dfsdfdsf', 'ADU220818013_1660785792.jpg', NULL, NULL, 'Pending', '2022-08-18 08:23:12', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (32, 'ADU220818014', '199105032022021001', 'Akhmad Masruri, S.Kom.', '085643538783', 'Dinas Kesehatan Temanggung', 'rewrwrewrw', 'kominfo.temanggungkab.go.id', 'dfsdfdsf', 'ADU220818014_1660785832.jpg', NULL, NULL, 'Pending', '2022-08-18 08:23:52', NULL, NULL, NULL, NULL);
INSERT INTO `tiket` (`id_tiket`, `no_tiket`, `nip`, `nama`, `no_wa`, `nama_opd`, `nama_aplikasi`, `link_aplikasi`, `deskripsi_kendala`, `bukti_kendala`, `deskripsi_tindaklanjut`, `deskripsi_penyelesaian`, `status`, `create_at`, `update_at`, `update_by`, `update_at2`, `update_by2`) VALUES (33, 'ADU220818015', '199105032022021001', 'Akhmad Masruri', '085643538783', '3213213123', 'rewrwrewrw', 'kominfo.temanggungkab.go.id', 'ssddsfsf', 'ADU220818015_1660792281.jpg', NULL, NULL, 'Pending', '2022-08-18 10:11:21', NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: user_access
#

DROP TABLE IF EXISTS `user_access`;

CREATE TABLE `user_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_group` int(11) DEFAULT NULL,
  `kd_access` varchar(12) DEFAULT NULL,
  `nm_access` varbinary(100) DEFAULT NULL,
  `is_allow` int(1) DEFAULT NULL COMMENT '0=false,1=true',
  `note` text DEFAULT NULL,
  `id_menu` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (76, 1, '24', NULL, 1, NULL, 5);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (77, 1, '23', NULL, 1, NULL, 18);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (78, 1, '22', NULL, 1, NULL, 13);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (79, 1, '21', NULL, 1, NULL, 33);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (80, 1, '20', NULL, 1, NULL, 19);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (81, 1, '19', NULL, 1, NULL, 6);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (82, 3, '23', NULL, 0, NULL, 18);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (83, 3, '19', NULL, 1, NULL, 6);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (84, 3, '20', NULL, 1, NULL, 19);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (85, 3, '21', NULL, 1, NULL, 33);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (86, 4, '19', NULL, 1, NULL, 6);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (87, 4, '20', NULL, 1, NULL, 19);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (88, 4, '21', NULL, 1, NULL, 33);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (89, 4, '23', NULL, 1, NULL, 18);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (90, 4, '24', NULL, 0, NULL, 5);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (91, 4, '28', NULL, 1, NULL, 29);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (92, 4, '27', NULL, 1, NULL, 28);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (94, 3, '25', NULL, 1, NULL, 20);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (95, 4, '26', NULL, 1, NULL, 25);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (96, 4, '30', NULL, 1, NULL, 14);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (97, 4, '22', NULL, 1, NULL, 13);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (98, 1, '32', NULL, 1, NULL, 17);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (99, 1, '31', NULL, 1, NULL, 15);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (100, 1, '30', NULL, 1, NULL, 14);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (101, 1, '28', NULL, 1, NULL, 29);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (102, 1, '27', NULL, 1, NULL, 28);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (103, 1, '26', NULL, 1, NULL, 25);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (104, 1, '25', NULL, 1, NULL, 20);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (105, 1, '33', NULL, 1, NULL, 16);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (106, 1, '34', NULL, 1, NULL, 25);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (107, 4, '34', NULL, 1, NULL, 25);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (108, 1, '35', NULL, 1, NULL, 32);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (109, 1, '36', NULL, 1, NULL, 28);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (110, 1, '37', NULL, 1, NULL, 29);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (111, 4, '35', NULL, 1, NULL, 32);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (112, 4, '36', NULL, 1, NULL, 28);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (113, 4, '37', NULL, 1, NULL, 29);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (114, 3, '26', NULL, 1, NULL, 25);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (115, 3, '27', NULL, 1, NULL, 28);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (116, 3, '28', NULL, 1, NULL, 29);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (117, 4, '38', NULL, 1, NULL, 32);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (118, 1, '38', NULL, 1, NULL, 32);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (119, 7, '21', NULL, 1, NULL, 33);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (120, 7, '39', NULL, 1, NULL, 37);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (121, 6, '21', NULL, 1, NULL, 33);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (122, 6, '39', NULL, 1, NULL, 37);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (123, 1, '40', NULL, 1, NULL, 37);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (124, 7, '41', NULL, 1, NULL, 6);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (125, 6, '41', NULL, 1, NULL, 6);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (126, 1, '42', NULL, 1, NULL, 37);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (127, 1, '41', NULL, 1, NULL, 6);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (128, 7, '43', NULL, 1, NULL, 37);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (129, 1, '43', NULL, 1, NULL, 37);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (130, 1, '39', NULL, 1, NULL, 37);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (131, 1, '44', NULL, 1, NULL, 6);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (132, 1, '45', NULL, 1, NULL, 33);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (133, 6, '44', NULL, 1, NULL, 6);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (134, 6, '45', NULL, 1, NULL, 33);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (135, 5, '21', NULL, 1, NULL, 33);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (136, 5, '22', NULL, 1, NULL, 13);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (137, 5, '39', NULL, 1, NULL, 37);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (138, 5, '44', NULL, 1, NULL, 6);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`, `id_menu`) VALUES (139, 5, '45', NULL, 1, NULL, 33);


#
# TABLE STRUCTURE FOR: user_group
#

DROP TABLE IF EXISTS `user_group`;

CREATE TABLE `user_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(255) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

INSERT INTO `user_group` (`id`, `group_name`, `note`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (1, 'Developer', 'full akses', NULL, NULL, NULL, NULL);
INSERT INTO `user_group` (`id`, `group_name`, `note`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (5, 'Admin PLAI', 'Admin PLAI', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00');
INSERT INTO `user_group` (`id`, `group_name`, `note`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (6, 'Pengawas PLAI', 'Pengawas PLAI', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00');
INSERT INTO `user_group` (`id`, `group_name`, `note`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (7, 'Programmer', 'Programmer', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: user_menu_access
#

DROP TABLE IF EXISTS `user_menu_access`;

CREATE TABLE `user_menu_access` (
  `id_user_menu_access` int(10) NOT NULL AUTO_INCREMENT,
  `id_menu` int(10) DEFAULT NULL,
  `id_group` int(10) DEFAULT NULL,
  PRIMARY KEY (`id_user_menu_access`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(250) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `id_group` int(11) DEFAULT NULL COMMENT 'fk dari tabel user_group',
  `foto` varchar(250) DEFAULT NULL,
  `telp` varchar(250) DEFAULT NULL,
  `note` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `note_1` text DEFAULT NULL,
  `id_desa` int(100) DEFAULT NULL COMMENT 'fk dari tabel desa',
  PRIMARY KEY (`id_user`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

INSERT INTO `users` (`id_user`, `fullname`, `username`, `password`, `email`, `id_group`, `foto`, `telp`, `note`, `created_by`, `updated_by`, `created_at`, `updated_at`, `note_1`, `id_desa`) VALUES (6, 'dev', 'dev', '227edf7c86c02a44d17eec9aa5b30cd1', 'dev@gmail.com', 1, '', '088805050000', 'Full Akses', 3, 6, '2022-04-25 08:09:00', '2022-04-25 10:32:31', '', NULL);
INSERT INTO `users` (`id_user`, `fullname`, `username`, `password`, `email`, `id_group`, `foto`, `telp`, `note`, `created_by`, `updated_by`, `created_at`, `updated_at`, `note_1`, `id_desa`) VALUES (12, 'Akhmad Masruri', 'masruri', '2ba0e2a704433fd60b22bb0772bed42d', 'masruri@gmail.com', 7, '', '085643538783', '1', 6, 0, '2022-08-01 11:21:39', '0000-00-00 00:00:00', '', NULL);
INSERT INTO `users` (`id_user`, `fullname`, `username`, `password`, `email`, `id_group`, `foto`, `telp`, `note`, `created_by`, `updated_by`, `created_at`, `updated_at`, `note_1`, `id_desa`) VALUES (13, 'Fahrudin Yuniwinanto', 'Fahrudin', 'e10adc3949ba59abbe56e057f20f883e', 'devteam.kominfotmg@gmail.com', 7, '', '089636555456', 'Tenaga Ahli Programmer', 6, 6, '2022-08-16 07:04:55', '2022-08-18 09:10:17', '', NULL);


